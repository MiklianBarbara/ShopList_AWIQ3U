SaveNotes
=========

Episode 6 of Firefox OS Tutorial - Local Storage (Persistence) - Simple Note Taking Application

The entire tutorial can be found at : http://www.rominirani.com/category/mobile-2/firefox-os/
